import java.util.ArrayList;
import java.util.Scanner;

public class Main {
        public static void main(String[] args) {
                Scanner sc = new Scanner(System.in);
                ArrayList<Integer> numeros = new ArrayList<Integer>();
                int numero;

                do {
                        System.out.print("Ingrese un número entero (0 para terminar): ");
                        numero = sc.nextInt();
                        if (numero != 0) {
                                numeros.add(numero);
                        }
                } while (numero != 0);

                if (numeros.size() < 3) {
                        System.out.println("Debe ingresar al menos tres números.");
                        return;
                }

                int suma = 0;
                int menor = numeros.get(0);
                int mayor = numeros.get(0);

                for (int i = 0; i < numeros.size(); i++) {
                        suma += numeros.get(i);
                        if (numeros.get(i) < menor) {
                                menor = numeros.get(i);
                        }
                        if (numeros.get(i) > mayor) {
                                mayor = numeros.get(i);
                        }
                }

                double promedio = (double) suma / numeros.size();

                System.out.println("Promedio: " + promedio);
                System.out.println("Menor valor: " + menor);
                System.out.println("Mayor valor: " + mayor);

                for (int i = 0; i < numeros.size(); i++) {
                        if (numeros.get(i) % 2 == 0) {
                                numeros.remove(i);
                                i--;
                        }
                }

                suma = 0;
                menor = numeros.get(0);
                mayor = numeros.get(0);

                for (int i = 0; i < numeros.size(); i++) {
                        suma += numeros.get(i);
                        if (numeros.get(i) < menor) {
                                menor = numeros.get(i);
                        }
                        if (numeros.get(i) > mayor) {
                                mayor = numeros.get(i);
                        }
                }

                promedio = (double) suma / numeros.size();

                System.out.println("Promedio sin números pares: " + promedio);
                System.out.println("Menor valor sin números pares: " + menor);
                System.out.println("Mayor valor sin números pares: " + mayor);
        }
}

